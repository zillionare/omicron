#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
quotes worker
"""
import logging

logger = logging.getLogger(__file__)
