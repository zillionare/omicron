::: omega
